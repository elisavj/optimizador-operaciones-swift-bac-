"""
Ejercicio 3 — Modelo Matemático de Asignación Binaria
Streamlit App: resuelve el problema con PuLP (sin necesidad de AMPL/solver externo)
y también genera/descarga los archivos AMPL.
"""

import streamlit as st
import pandas as pd
import numpy as np
from pulp import (
    LpProblem, LpMinimize, LpVariable, lpSum,
    value, LpStatus, PULP_CBC_CMD
)
import io

# ─────────────────────────────────────────────
# CONFIGURACIÓN DE LA PÁGINA
# ─────────────────────────────────────────────
st.set_page_config(
    page_title="Asignación Binaria — Ejercicio 3",
    page_icon="🔢",
    layout="wide",
)

# ─────────────────────────────────────────────
# DATOS BASE
# ─────────────────────────────────────────────
ANALISTAS   = ["A", "B", "C", "D", "E"]
NOMBRES     = {"A": "Andrea", "B": "Beatriz", "C": "Carlos", "D": "Daniel", "E": "Esteban"}
OPERACIONES = ["MT103", "MT202", "MT700", "MT760", "MT940"]
INF         = 9999   # valor para celda bloqueada

TIEMPOS_BASE = {
    ("A","MT103"): 25, ("A","MT202"): 30, ("A","MT700"): INF, ("A","MT760"): INF, ("A","MT940"): 20,
    ("B","MT103"): 35, ("B","MT202"): 28, ("B","MT700"): 40,  ("B","MT760"): 45,  ("B","MT940"): 22,
    ("C","MT103"): 40, ("C","MT202"): 45, ("C","MT700"): 35,  ("C","MT760"): 30,  ("C","MT940"): 25,
    ("D","MT103"): 30, ("D","MT202"): 32, ("D","MT700"): 50,  ("D","MT760"): INF, ("D","MT940"): 18,
    ("E","MT103"): INF,("E","MT202"): INF,("E","MT700"): 30,  ("E","MT760"): 28,  ("E","MT940"): 30,
}

COMPLIANCE = [("A","MT700"),("A","MT760"),("D","MT760"),("E","MT103"),("E","MT202")]

# ─────────────────────────────────────────────
# FUNCIONES
# ─────────────────────────────────────────────

def build_dataframe(tiempos):
    """Construye DataFrame para mostrar la tabla de tiempos."""
    rows = []
    for a in ANALISTAS:
        row = {}
        for o in OPERACIONES:
            v = tiempos[(a, o)]
            row[o] = "🚫" if v == INF else v
        rows.append(row)
    df = pd.DataFrame(rows, index=[f"{NOMBRES[a]} ({a})" for a in ANALISTAS])
    return df


def solve_model(tiempos):
    """Resuelve el modelo de PL binaria con PuLP."""
    prob = LpProblem("Asignacion_Binaria", LpMinimize)

    # Variables
    x = {(a, o): LpVariable(f"x_{a}_{o}", cat="Binary")
         for a in ANALISTAS for o in OPERACIONES}

    # Función objetivo
    prob += lpSum(tiempos[(a, o)] * x[(a, o)]
                  for a in ANALISTAS for o in OPERACIONES
                  if tiempos[(a, o)] < INF)

    # R1: cada operación asignada a exactamente 1 analista
    for o in OPERACIONES:
        prob += lpSum(x[(a, o)] for a in ANALISTAS) == 1, f"op_{o}"

    # R2: cada analista asignado a exactamente 1 operación
    for a in ANALISTAS:
        prob += lpSum(x[(a, o)] for o in OPERACIONES) == 1, f"analista_{a}"

    # R3: compliance — variables fijas en 0
    for (a, o) in COMPLIANCE:
        prob += x[(a, o)] == 0, f"compliance_{a}_{o}"

    prob.solve(PULP_CBC_CMD(msg=0))

    status = LpStatus[prob.status]
    z      = value(prob.objective)
    sol    = {(a, o): int(round(value(x[(a, o)])))
              for a in ANALISTAS for o in OPERACIONES}
    return status, z, sol


def generate_ampl_mod():
    return """\
# ============================================================
# EJERCICIO 3 — Modelo de Asignación Binaria
# 5 analistas × 5 operaciones = 25 variables binarias
# ============================================================

set ANALISTAS;
set OPERACIONES;

param tiempo{ANALISTAS, OPERACIONES} default 9999;

var x{ANALISTAS, OPERACIONES} binary;

minimize Z:
    sum{a in ANALISTAS, o in OPERACIONES} tiempo[a,o] * x[a,o];

subject to una_por_operacion{o in OPERACIONES}:
    sum{a in ANALISTAS} x[a,o] = 1;

subject to una_por_analista{a in ANALISTAS}:
    sum{o in OPERACIONES} x[a,o] = 1;

subject to compliance_xA_MT700: x["A","MT700"] = 0;
subject to compliance_xA_MT760: x["A","MT760"] = 0;
subject to compliance_xD_MT760: x["D","MT760"] = 0;
subject to compliance_xE_MT103: x["E","MT103"] = 0;
subject to compliance_xE_MT202: x["E","MT202"] = 0;
"""

def generate_ampl_dat(tiempos):
    lines = ["# ============================================================",
             "# DATOS — Ejercicio 3",
             "# ============================================================",
             "",
             "set ANALISTAS := A B C D E;",
             "set OPERACIONES := MT103 MT202 MT700 MT760 MT940;",
             "",
             "param tiempo :"]
    header = "          " + "  ".join(f"{o:>6}" for o in OPERACIONES) + " :="
    lines.append(header)
    for a in ANALISTAS:
        vals = "  ".join(f"{tiempos[(a,o)]:>6}" for o in OPERACIONES)
        prefix = "    " + f"{a:<6}"
        lines.append(prefix + vals)
    lines.append("    ;")
    return "\n".join(lines)

def generate_ampl_run():
    return """\
reset;

model asignacion.mod;
data  asignacion.dat;

option solver cbc;   # cambiar a cplex o glpk si se prefiere

solve;

printf "\\n====================================================\\n";
printf "   SOLUCIÓN ÓPTIMA — Asignación de Operaciones\\n";
printf "====================================================\\n";

printf "\\nAsignación óptima:\\n";
for {a in ANALISTAS, o in OPERACIONES: x[a,o] > 0.5} {
    printf "  %-6s -> %-8s  (%d min)\\n", a, o, tiempo[a,o];
}

printf "\\nTiempo total mínimo: %d minutos\\n\\n", Z;
"""

# ─────────────────────────────────────────────
# SIDEBAR — Edición de tiempos
# ─────────────────────────────────────────────
st.sidebar.header("⚙️ Parámetros del modelo")
st.sidebar.caption("Modifica los tiempos (celdas bloqueadas = 9999)")

tiempos = dict(TIEMPOS_BASE)
with st.sidebar.expander("Editar tiempos manualmente", expanded=False):
    for a in ANALISTAS:
        st.markdown(f"**{NOMBRES[a]} ({a})**")
        cols = st.columns(5)
        for i, o in enumerate(OPERACIONES):
            blocked = (a, o) in COMPLIANCE
            val = tiempos[(a, o)]
            new_val = cols[i].number_input(
                o, value=val, min_value=0, max_value=9999,
                step=1, key=f"t_{a}_{o}",
                disabled=blocked,
                help="🚫 Bloqueado por compliance" if blocked else ""
            )
            tiempos[(a, o)] = new_val

# ─────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────
st.title("🔢 Ejercicio 3 — Modelo Matemático de Asignación Binaria")
st.caption("Programación Entera Binaria · 5 analistas × 5 operaciones · Restricciones Compliance Bridger")

tab1, tab2, tab3 = st.tabs(["📊 Datos & Solución", "📄 Archivos AMPL", "📐 Formulación"])

# ══════════════════════════════════════════════
# TAB 1 — DATOS & SOLUCIÓN
# ══════════════════════════════════════════════
with tab1:
    col_a, col_b = st.columns([1.1, 1])

    with col_a:
        st.subheader("Tabla de tiempos (min)")
        df = build_dataframe(tiempos)

        # Colorear celdas bloqueadas
        def highlight_blocked(val):
            return "background-color: #ffe0e0; color: #cc0000; font-weight: bold;" if val == "🚫" else ""

        st.dataframe(df.style.applymap(highlight_blocked), use_container_width=True)

        st.markdown("##### Restricciones de compliance")
        comp_data = {
            "Analista": ["Andrea (A)", "Andrea (A)", "Daniel (D)", "Esteban (E)", "Esteban (E)"],
            "Operación bloqueada": ["MT700", "MT760", "MT760", "MT103", "MT202"],
            "Motivo": ["LC", "Garantía", "Garantía", "Re-certificación", "Re-certificación"],
        }
        st.dataframe(pd.DataFrame(comp_data), use_container_width=True, hide_index=True)

    with col_b:
        st.subheader("Resolver el modelo")

        if st.button("▶️ Resolver con CBC (PuLP)", type="primary", use_container_width=True):
            with st.spinner("Optimizando…"):
                status, z, sol = solve_model(tiempos)

            if status == "Optimal":
                st.success(f"✅ Solución **óptima** encontrada  |  **Z = {int(z)} minutos**")

                # Tabla de asignaciones
                assigns = [(NOMBRES[a], a, o, tiempos[(a, o)])
                           for a in ANALISTAS for o in OPERACIONES if sol[(a, o)] == 1]
                df_sol = pd.DataFrame(assigns, columns=["Analista", "Código", "Operación", "Tiempo (min)"])
                st.dataframe(df_sol, use_container_width=True, hide_index=True)

                # Mapa visual de asignación
                st.markdown("##### Mapa de asignación")
                matrix = pd.DataFrame("", index=[f"{NOMBRES[a]} ({a})" for a in ANALISTAS],
                                      columns=OPERACIONES)
                for a in ANALISTAS:
                    for o in OPERACIONES:
                        if sol[(a, o)] == 1:
                            matrix.loc[f"{NOMBRES[a]} ({a})", o] = f"✅ {tiempos[(a,o)]} min"
                        elif (a, o) in COMPLIANCE:
                            matrix.loc[f"{NOMBRES[a]} ({a})", o] = "🚫"
                        else:
                            matrix.loc[f"{NOMBRES[a]} ({a})", o] = f"{tiempos[(a,o)]}"

                def style_matrix(val):
                    if "✅" in str(val): return "background-color:#d4edda;font-weight:bold;color:#155724"
                    if "🚫" in str(val): return "background-color:#ffe0e0;color:#cc0000"
                    return ""

                st.dataframe(matrix.style.applymap(style_matrix), use_container_width=True)

            elif status == "Infeasible":
                st.error("❌ El modelo es **infactible**. Revisa los tiempos y las restricciones de compliance.")
            else:
                st.warning(f"⚠️ Estado del solver: {status}")

# ══════════════════════════════════════════════
# TAB 2 — ARCHIVOS AMPL
# ══════════════════════════════════════════════
with tab2:
    st.subheader("Descargar archivos AMPL")
    st.info("Estos archivos son compatibles con AMPL + solver CBC, CPLEX o GLPK.")

    col1, col2, col3 = st.columns(3)

    mod_text = generate_ampl_mod()
    dat_text = generate_ampl_dat(tiempos)
    run_text = generate_ampl_run()

    with col1:
        st.download_button("⬇️ asignacion.mod", mod_text, "asignacion.mod", "text/plain", use_container_width=True)
        st.code(mod_text, language="text")

    with col2:
        st.download_button("⬇️ asignacion.dat", dat_text, "asignacion.dat", "text/plain", use_container_width=True)
        st.code(dat_text, language="text")

    with col3:
        st.download_button("⬇️ asignacion.run", run_text, "asignacion.run", "text/plain", use_container_width=True)
        st.code(run_text, language="text")

# ══════════════════════════════════════════════
# TAB 3 — FORMULACIÓN
# ══════════════════════════════════════════════
with tab3:
    st.subheader("Formulación matemática")

    st.markdown(r"""
### Variables de decisión

$$x_{a,o} \in \{0,1\} \quad \forall\, a \in \text{Analistas},\; o \in \text{Operaciones}$$

$x_{a,o} = 1$ si el analista $a$ ejecuta la operación $o$, 0 en otro caso.

---

### Función objetivo

$$\min Z = \sum_{a \in A} \sum_{o \in O} t_{a,o} \cdot x_{a,o}$$

---

### Restricciones

**Cada operación debe ser ejecutada por exactamente 1 analista:**

$$\sum_{a \in A} x_{a,o} = 1 \quad \forall\, o \in O \quad (5 \text{ restricciones})$$

**Cada analista ejecuta exactamente 1 operación:**

$$\sum_{o \in O} x_{a,o} = 1 \quad \forall\, a \in A \quad (5 \text{ restricciones})$$

**Restricciones de compliance (5 celdas bloqueadas):**

$$x_{A,MT700} = 0, \quad x_{A,MT760} = 0$$
$$x_{D,MT760} = 0$$
$$x_{E,MT103} = 0, \quad x_{E,MT202} = 0$$

**Dominio:**

$$x_{a,o} \in \{0,1\} \quad \forall\, a, o$$

---

| Componente | Cantidad |
|---|---|
| Variables binarias | 25 |
| Restricciones de operación | 5 |
| Restricciones de analista | 5 |
| Restricciones de compliance | 5 |
| **Total restricciones** | **15** |
""")
