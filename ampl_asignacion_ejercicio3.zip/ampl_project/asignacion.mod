# ============================================================
# EJERCICIO 3 — Modelo de Asignación Binaria
# 5 analistas × 5 operaciones = 25 variables binarias
# ============================================================

# --- CONJUNTOS ---
set ANALISTAS;
set OPERACIONES;

# --- PARÁMETROS ---
param tiempo{ANALISTAS, OPERACIONES} default 9999;  # 9999 = no asignable (compliance)

# --- VARIABLES DE DECISIÓN ---
var x{ANALISTAS, OPERACIONES} binary;

# --- FUNCIÓN OBJETIVO ---
minimize Z: sum{a in ANALISTAS, o in OPERACIONES} tiempo[a,o] * x[a,o];

# --- RESTRICCIONES ---

# Cada operación debe ser ejecutada por exactamente 1 analista
subject to una_por_operacion{o in OPERACIONES}:
    sum{a in ANALISTAS} x[a,o] = 1;

# Cada analista ejecuta exactamente 1 operación
subject to una_por_analista{a in ANALISTAS}:
    sum{o in OPERACIONES} x[a,o] = 1;

# Restricciones de compliance (celdas bloqueadas = 0)
# Andrea no puede hacer MT700 ni MT760
subject to compliance_xA3: x["A","MT700"] = 0;
subject to compliance_xA4: x["A","MT760"] = 0;

# Daniel no puede hacer MT760
subject to compliance_xD4: x["D","MT760"] = 0;

# Esteban no puede hacer MT103 ni MT202
subject to compliance_xE1: x["E","MT103"] = 0;
subject to compliance_xE2: x["E","MT202"] = 0;
