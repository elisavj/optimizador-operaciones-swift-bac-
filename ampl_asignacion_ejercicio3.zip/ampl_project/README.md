# Ejercicio 3 — Modelo Matemático de Asignación Binaria

Aplicación Streamlit que resuelve un problema de **Programación Entera Binaria** de asignación de operaciones bancarias a analistas, con restricciones de compliance.

## 🧩 Descripción del Problema

**5 analistas** (Andrea, Beatriz, Carlos, Daniel, Esteban) deben ser asignados a **5 operaciones** (MT103, MT202, MT700, MT760, MT940) de manera que se minimice el tiempo total de procesamiento.

### Restricciones de compliance Bridger
| Analista | Operación bloqueada | Motivo |
|---|---|---|
| Andrea (A) | MT700 | LC |
| Andrea (A) | MT760 | Garantía |
| Daniel (D) | MT760 | Garantía |
| Esteban (E) | MT103 | Re-certificación |
| Esteban (E) | MT202 | Re-certificación |

## 📐 Formulación

**Variables:** $x_{a,o} \in \{0,1\}$ — 1 si el analista $a$ ejecuta la operación $o$

**Objetivo:** $\min Z = \sum_{a,o} t_{a,o} \cdot x_{a,o}$

**Restricciones:**
- Cada operación asignada a exactamente 1 analista
- Cada analista asignado a exactamente 1 operación
- 5 restricciones de compliance (variables forzadas a 0)

## 🗂️ Archivos del repositorio

```
├── app.py              # Aplicación Streamlit principal
├── asignacion.mod      # Modelo AMPL
├── asignacion.dat      # Datos AMPL
├── asignacion.run      # Script de ejecución AMPL
├── requirements.txt    # Dependencias Python
└── README.md
```

## 🚀 Ejecutar localmente

```bash
git clone https://github.com/TU_USUARIO/REPO_NAME.git
cd REPO_NAME
pip install -r requirements.txt
streamlit run app.py
```

## ☁️ Deploy en Streamlit Cloud

1. Sube el repositorio a GitHub
2. Ve a [share.streamlit.io](https://share.streamlit.io)
3. Conecta tu repo y selecciona `app.py` como archivo principal
4. Deploy 🎉

## 🔧 Ejecutar modelo AMPL

```bash
ampl asignacion.run
```

Requiere AMPL instalado con solver **CBC**, **CPLEX** o **GLPK**.

## 📦 Dependencias

- `streamlit` — interfaz web
- `pulp` — solver de PL (incluye CBC open-source)
- `pandas` / `numpy` — manejo de datos
